# VT.624_klipper_config_backup

Klipper config backup for Doom Trident 300 <sup>2</sup> x 350.

## WARNING

This config is a copy and pasted Frankenstein combining <a href="https://github.com/Hartk-PrinterConfigs/LDOv2Config"> hartk's config </a> , <a href="https://github.com/AndrewEllis93"> AndrewEllis93's config and macros </a>, <a href="https://github.com/jlas1/Klicky-Probe"> Klicky macros (with Euclid Probe) </a> and <a href="https://github.com/kyleisah/Klipper-Adaptive-Meshing-Purging"> Klyeisah's Adaptive Bed Mesh. </a>

Please don't copy just one macro expecting it to work. It probably calls a separate override macro somewhere in the config.


## Contact

Contact me via Discord, outrider305#4587.